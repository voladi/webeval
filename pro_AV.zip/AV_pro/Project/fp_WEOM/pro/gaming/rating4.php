<?php
include_once 'dbConfig.php';
if(!empty($_POST['ratingPoints'])){
    $postID = $_POST['postID'];
    $ratingNum = 1;
    $ratingPoints = $_POST['ratingPoints'];
    
    //Check the rating row with same post ID
    $prevRatingQuery = "SELECT * FROM g4 WHERE post_id = ".$postID;
    $prevRatingResult = $db->query($prevRatingQuery);
    if($prevRatingResult->num_rows > 0):
        $prevRatingRow = $prevRatingResult->fetch_assoc();
        $ratingNum = $prevRatingRow['rating_number10'] + $ratingNum;
        $ratingPoints = $prevRatingRow['total_points10'] + $ratingPoints;
        //Update rating data into the database
        $query = "UPDATE g4 SET rating_number10 = '".$ratingNum."', total_points10 = '".$ratingPoints."', modified = '".date("Y-m-d H:i:s")."' WHERE post_id = ".$postID;
        $update = $db->query($query);
    else:
        //Insert rating data into the database
        $query = "INSERT INTO g4 (post_id,rating_number10,total_points10,created,modified) VALUES(".$postID.",'".$ratingNum."','".$ratingPoints."','".date("Y-m-d H:i:s")."','".date("Y-m-d H:i:s")."')";
        $insert = $db->query($query);
    endif;
    
    //Fetch rating deatails from database
    $query = "SELECT rating_number10, FORMAT((total_points10 / rating_number10),1) as average_rating10 FROM g4 WHERE post_id = ".$postID." AND status = 1";
    $result4 = $db->query($query);
    $ratingRow10 = $result4->fetch_assoc();
    
    if($ratingRow10){
        $ratingRow10['status'] = 'ok';
    }else{
        $ratingRow10['status'] = 'err';
    }
    
    //Return json formatted rating data
    echo json_encode($ratingRow10);
}
?>