<?php
include_once 'dbConfig.php';
if(!empty($_POST['ratingPoints'])){
    $postID = $_POST['postID'];
    $ratingNum = 1;
    $ratingPoints = $_POST['ratingPoints'];
    
    //Check the rating row with same post ID
    $prevRatingQuery = "SELECT * FROM g1 WHERE post_id = ".$postID;
    $prevRatingResult = $db->query($prevRatingQuery);
    if($prevRatingResult->num_rows > 0):
        $prevRatingRow = $prevRatingResult->fetch_assoc();
        $ratingNum = $prevRatingRow['rating_number7'] + $ratingNum;
        $ratingPoints = $prevRatingRow['total_points7'] + $ratingPoints;
        //Update rating data into the database
        $query = "UPDATE g1 SET rating_number7 = '".$ratingNum."', total_points7 = '".$ratingPoints."', modified = '".date("Y-m-d H:i:s")."' WHERE post_id = ".$postID;
        $update = $db->query($query);
    else:
        //Insert rating data into the database
        $query = "INSERT INTO g1 (post_id,rating_number7,total_points7,created,modified) VALUES(".$postID.",'".$ratingNum."','".$ratingPoints."','".date("Y-m-d H:i:s")."','".date("Y-m-d H:i:s")."')";
        $insert = $db->query($query);
    endif;
    
    //Fetch rating deatails from database
    $query7 = "SELECT rating_number7, FORMAT((total_points7 / rating_number7),1) as average_rating7 FROM g1 WHERE post_id = ".$postID." AND status = 1";
    $result7 = $db->query($query7);
    $ratingRow7 = $result7->fetch_assoc();
    
    if($ratingRow7){
        $ratingRow7['status'] = 'ok';
    }else{
        $ratingRow7['status'] = 'err';
    }
    
    //Return json formatted rating data
    echo json_encode($ratingRow7);
}
?>