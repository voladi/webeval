<?php
include_once 'dbConfig.php';
if(!empty($_POST['ratingPoints'])){
    $postID = $_POST['postID'];
    $ratingNum = 1;
    $ratingPoints = $_POST['ratingPoints'];
    
    //Check the rating row with same post ID
    $prevRatingQuery = "SELECT * FROM g3 WHERE post_id = ".$postID;
    $prevRatingResult = $db->query($prevRatingQuery);
    if($prevRatingResult->num_rows > 0):
        $prevRatingRow = $prevRatingResult->fetch_assoc();
        $ratingNum = $prevRatingRow['rating_number9'] + $ratingNum;
        $ratingPoints = $prevRatingRow['total_points9'] + $ratingPoints;
        //Update rating data into the database
        $query = "UPDATE g3 SET rating_number9 = '".$ratingNum."', total_points9 = '".$ratingPoints."', modified = '".date("Y-m-d H:i:s")."' WHERE post_id = ".$postID;
        $update = $db->query($query);
    else:
        //Insert rating data into the database
        $query = "INSERT INTO g3 (post_id,rating_number9,total_points9,created,modified) VALUES(".$postID.",'".$ratingNum."','".$ratingPoints."','".date("Y-m-d H:i:s")."','".date("Y-m-d H:i:s")."')";
        $insert = $db->query($query);
    endif;
    
    //Fetch rating deatails from database
    $query = "SELECT rating_number9, FORMAT((total_points9 / rating_number9),1) as average_rating9 FROM g3 WHERE post_id = ".$postID." AND status = 1";
    $result3 = $db->query($query);
    $ratingRow9 = $result3->fetch_assoc();
    
    if($ratingRow9){
        $ratingRow9['status'] = 'ok';
    }else{
        $ratingRow9['status'] = 'err';
    }
    
    //Return json formatted rating data
    echo json_encode($ratingRow9);
}
?>