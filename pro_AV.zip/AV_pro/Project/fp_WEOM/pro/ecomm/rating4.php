<?php
include_once 'dbConfig.php';
if(!empty($_POST['ratingPoints'])){
    $postID = $_POST['postID'];
    $ratingNum = 1;
    $ratingPoints = $_POST['ratingPoints'];
    
    //Check the rating row with same post ID
    $prevRatingQuery = "SELECT * FROM e4 WHERE post_id = ".$postID;
    $prevRatingResult = $db->query($prevRatingQuery);
    if($prevRatingResult->num_rows > 0):
        $prevRatingRow = $prevRatingResult->fetch_assoc();
        $ratingNum = $prevRatingRow['rating_number4'] + $ratingNum;
        $ratingPoints = $prevRatingRow['total_points4'] + $ratingPoints;
        //Update rating data into the database
        $query = "UPDATE e4 SET rating_number4 = '".$ratingNum."', total_points4 = '".$ratingPoints."', modified = '".date("Y-m-d H:i:s")."' WHERE post_id = ".$postID;
        $update = $db->query($query);
    else:
        //Insert rating data into the database
        $query = "INSERT INTO e4 (post_id,rating_number4,total_points4,created,modified) VALUES(".$postID.",'".$ratingNum."','".$ratingPoints."','".date("Y-m-d H:i:s")."','".date("Y-m-d H:i:s")."')";
        $insert = $db->query($query);
    endif;
    
    //Fetch rating deatails from database
    $query = "SELECT rating_number4, FORMAT((total_points4 / rating_number4),1) as average_rating4 FROM e4 WHERE post_id = ".$postID." AND status = 1";
    $result4 = $db->query($query);
    $ratingRow4 = $result4->fetch_assoc();
    
    if($ratingRow4){
        $ratingRow4['status'] = 'ok';
    }else{
        $ratingRow4['status'] = 'err';
    }
    
    //Return json formatted rating data
    echo json_encode($ratingRow4);
}
?>