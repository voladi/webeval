<?php
include_once 'dbConfig.php';
if(!empty($_POST['ratingPoints'])){
    $postID = $_POST['postID'];
    $ratingNum = 1;
    $ratingPoints = $_POST['ratingPoints'];
    
    //Check the rating row with same post ID
    $prevRatingQuery = "SELECT * FROM e2 WHERE post_id = ".$postID;
    $prevRatingResult = $db->query($prevRatingQuery);
    if($prevRatingResult->num_rows > 0):
        $prevRatingRow = $prevRatingResult->fetch_assoc();
        $ratingNum = $prevRatingRow['rating_number2'] + $ratingNum;
        $ratingPoints = $prevRatingRow['total_points2'] + $ratingPoints;
        //Update rating data into the database
        $query = "UPDATE e2 SET rating_number2 = '".$ratingNum."', total_points2 = '".$ratingPoints."', modified = '".date("Y-m-d H:i:s")."' WHERE post_id = ".$postID;
        $update = $db->query($query);
    else:
        //Insert rating data into the database
        $query = "INSERT INTO e2 (post_id,rating_number2,total_points2,created,modified) VALUES(".$postID.",'".$ratingNum."','".$ratingPoints."','".date("Y-m-d H:i:s")."','".date("Y-m-d H:i:s")."')";
        $insert = $db->query($query);
    endif;
    
    //Fetch rating deatails from database
    $query = "SELECT rating_number2, FORMAT((total_points2 / rating_number2),1) as average_rating2 FROM e2 WHERE post_id = ".$postID." AND status = 1";
    $result2 = $db->query($query);
    $ratingRow2 = $result2->fetch_assoc();
    
    if($ratingRow2){
        $ratingRow2['status'] = 'ok';
    }else{
        $ratingRow2['status'] = 'err';
    }
    
    //Return json formatted rating data
    echo json_encode($ratingRow2);
}
?>