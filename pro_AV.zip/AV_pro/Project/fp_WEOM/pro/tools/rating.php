<?php
include_once 'dbConfig.php';
if(!empty($_POST['ratingPoints'])){
    $postID = $_POST['postID'];
    $ratingNum = 1;
    $ratingPoints = $_POST['ratingPoints'];
    
    //Check the rating row with same post ID
    $t1evRatingQuery = "SELECT * FROM t1 WHERE post_id = ".$postID;
    $t1evRatingResult = $db->query($t1evRatingQuery);
    if($t1evRatingResult->num_rows > 0):
        $t1evRatingRow = $t1evRatingResult->fetch_assoc();
        $ratingNum = $t1evRatingRow['rating_number25'] + $ratingNum;
        $ratingPoints = $t1evRatingRow['total_points25'] + $ratingPoints;
        //Update rating data into the database
        $query = "UPDATE t1 SET rating_number25 = '".$ratingNum."', total_points25 = '".$ratingPoints."', modified = '".date("Y-m-d H:i:s")."' WHERE post_id = ".$postID;
        $update = $db->query($query);
    else:
        //Insert rating data into the database
        $query = "INSERT INTO t1 (post_id,rating_number25,total_points25,created,modified) VALUES(".$postID.",'".$ratingNum."','".$ratingPoints."','".date("Y-m-d H:i:s")."','".date("Y-m-d H:i:s")."')";
        $insert = $db->query($query);
    endif;
    
    //Fetch rating deatails from database
    $query = "SELECT rating_number25, FORMAT((total_points25 / rating_number25),1) as average_rating25 FROM t1 WHERE post_id = ".$postID." AND status = 1";
    $result = $db->query($query);
    $ratingRow25 = $result->fetch_assoc();
    
    if($ratingRow25){
        $ratingRow25['status'] = 'ok';
    }else{
        $ratingRow25['status'] = 'err';
    }
    
    //Return json formatted rating data
    echo json_encode($ratingRow25);
}
?>