<?php
include_once 'dbConfig.php';
if(!empty($_POST['ratingPoints'])){
    $postID = $_POST['postID'];
    $ratingNum = 1;
    $ratingPoints = $_POST['ratingPoints'];
    
    //Check the rating row with same post ID
    $prevRatingQuery = "SELECT * FROM t2 WHERE post_id = ".$postID;
    $prevRatingResult = $db->query($prevRatingQuery);
    if($prevRatingResult->num_rows > 0):
        $prevRatingRow = $prevRatingResult->fetch_assoc();
        $ratingNum = $prevRatingRow['rating_number26'] + $ratingNum;
        $ratingPoints = $prevRatingRow['total_points26'] + $ratingPoints;
        //Update rating data into the database
        $query = "UPDATE t2 SET rating_number26 = '".$ratingNum."', total_points26 = '".$ratingPoints."', modified = '".date("Y-m-d H:i:s")."' WHERE post_id = ".$postID;
        $update = $db->query($query);
    else:
        //Insert rating data into the database
        $query = "INSERT INTO t2 (post_id,rating_number26,total_points26,created,modified) VALUES(".$postID.",'".$ratingNum."','".$ratingPoints."','".date("Y-m-d H:i:s")."','".date("Y-m-d H:i:s")."')";
        $insert = $db->query($query);
    endif;
    
    //Fetch rating deatails from database
    $query = "SELECT rating_number26, FORMAT((total_points26 / rating_number26),1) as average_rating26 FROM t2 WHERE post_id = ".$postID." AND status = 1";
    $result2 = $db->query($query);
    $ratingRow26 = $result2->fetch_assoc();
    
    if($ratingRow26){
        $ratingRow26['status'] = 'ok';
    }else{
        $ratingRow26['status'] = 'err';
    }
    
    //Return json formatted rating data
    echo json_encode($ratingRow26);
}
?>