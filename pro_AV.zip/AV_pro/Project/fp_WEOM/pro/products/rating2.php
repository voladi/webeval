<?php
include_once 'dbConfig.php';
if(!empty($_POST['ratingPoints'])){
    $postID = $_POST['postID'];
    $ratingNum = 1;
    $ratingPoints = $_POST['ratingPoints'];
    
    //Check the rating row with same post ID
    $prevRatingQuery = "SELECT * FROM p2 WHERE post_id = ".$postID;
    $prevRatingResult = $db->query($prevRatingQuery);
    if($prevRatingResult->num_rows > 0):
        $prevRatingRow = $prevRatingResult->fetch_assoc();
        $ratingNum = $prevRatingRow['rating_number20'] + $ratingNum;
        $ratingPoints = $prevRatingRow['total_points20'] + $ratingPoints;
        //Update rating data into the database
        $query = "UPDATE p2 SET rating_number20 = '".$ratingNum."', total_points20 = '".$ratingPoints."', modified = '".date("Y-m-d H:i:s")."' WHERE post_id = ".$postID;
        $update = $db->query($query);
    else:
        //Insert rating data into the database
        $query = "INSERT INTO p2 (post_id,rating_number20,total_points20,created,modified) VALUES(".$postID.",'".$ratingNum."','".$ratingPoints."','".date("Y-m-d H:i:s")."','".date("Y-m-d H:i:s")."')";
        $insert = $db->query($query);
    endif;
    
    //Fetch rating deatails from database
    $query = "SELECT rating_number20, FORMAT((total_points20 / rating_number20),1) as average_rating20 FROM p2 WHERE post_id = ".$postID." AND status = 1";
    $result2 = $db->query($query);
    $ratingRow20 = $result2->fetch_assoc();
    
    if($ratingRow20){
        $ratingRow20['status'] = 'ok';
    }else{
        $ratingRow20['status'] = 'err';
    }
    
    //Return json formatted rating data
    echo json_encode($ratingRow20);
}
?>