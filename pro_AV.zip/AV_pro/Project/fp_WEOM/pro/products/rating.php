<?php
include_once 'dbConfig.php';
if(!empty($_POST['ratingPoints'])){
    $postID = $_POST['postID'];
    $ratingNum = 1;
    $ratingPoints = $_POST['ratingPoints'];
    
    //Check the rating row with same post ID
    $p1evRatingQuery = "SELECT * FROM p1 WHERE post_id = ".$postID;
    $p1evRatingResult = $db->query($p1evRatingQuery);
    if($p1evRatingResult->num_rows > 0):
        $p1evRatingRow = $p1evRatingResult->fetch_assoc();
        $ratingNum = $p1evRatingRow['rating_number19'] + $ratingNum;
        $ratingPoints = $p1evRatingRow['total_points19'] + $ratingPoints;
        //Update rating data into the database
        $query = "UPDATE p1 SET rating_number19 = '".$ratingNum."', total_points19 = '".$ratingPoints."', modified = '".date("Y-m-d H:i:s")."' WHERE post_id = ".$postID;
        $update = $db->query($query);
    else:
        //Insert rating data into the database
        $query = "INSERT INTO p1 (post_id,rating_number19,total_points19,created,modified) VALUES(".$postID.",'".$ratingNum."','".$ratingPoints."','".date("Y-m-d H:i:s")."','".date("Y-m-d H:i:s")."')";
        $insert = $db->query($query);
    endif;
    
    //Fetch rating deatails from database
    $query = "SELECT rating_number19, FORMAT((total_points19 / rating_number19),1) as average_rating19 FROM p1 WHERE post_id = ".$postID." AND status = 1";
    $result = $db->query($query);
    $ratingRow19 = $result->fetch_assoc();
    
    if($ratingRow19){
        $ratingRow19['status'] = 'ok';
    }else{
        $ratingRow19['status'] = 'err';
    }
    
    //Return json formatted rating data
    echo json_encode($ratingRow19);
}
?>