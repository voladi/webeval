<?php
include_once 'dbConfig.php';
if(!empty($_POST['ratingPoints'])){
    $postID = $_POST['postID'];
    $ratingNum = 1;
    $ratingPoints = $_POST['ratingPoints'];
    
    //Check the rating row with same post ID
    $prevRatingQuery = "SELECT * FROM p6 WHERE post_id = ".$postID;
    $prevRatingResult = $db->query($prevRatingQuery);
    if($prevRatingResult->num_rows > 0):
        $prevRatingRow = $prevRatingResult->fetch_assoc();
        $ratingNum = $prevRatingRow['rating_number24'] + $ratingNum;
        $ratingPoints = $prevRatingRow['total_points24'] + $ratingPoints;
        //Update rating data into the database
        $query = "UPDATE p6 SET rating_number24 = '".$ratingNum."', total_points24 = '".$ratingPoints."', modified = '".date("Y-m-d H:i:s")."' WHERE post_id = ".$postID;
        $update = $db->query($query);
    else:
        //Insert rating data into the database
        $query = "INSERT INTO p6 (post_id,rating_number24,total_points24,created,modified) VALUES(".$postID.",'".$ratingNum."','".$ratingPoints."','".date("Y-m-d H:i:s")."','".date("Y-m-d H:i:s")."')";
        $insert = $db->query($query);
    endif;
    
    //Fetch rating deatails from database
    $query = "SELECT rating_number24, FORMAT((total_points24 / rating_number24),1) as average_rating24 FROM p6 WHERE post_id = ".$postID." AND status = 1";
    $result6 = $db->query($query);
    $ratingRow24 = $result6->fetch_assoc();
    
    if($ratingRow24){
        $ratingRow24['status'] = 'ok';
    }else{
        $ratingRow24['status'] = 'err';
    }
    
    //Return json formatted rating data
    echo json_encode($ratingRow24);
}
?>