

<?php
include_once 'dbConfig.php';
//Fetch rating deatails from database
$query = "SELECT rating_number, FORMAT((total_points / rating_number),1) as average_rating FROM e1 WHERE post_id = 1 AND status = 1";
$result = $db->query($query);
$ratingRow = $result->fetch_assoc();

$query2 = "SELECT rating_number2, FORMAT((total_points2 / rating_number2),1) as average_rating2 FROM e2 WHERE post_id = 1 AND status = 1";
$result2 = $db->query($query2);
$ratingRow2 = $result2->fetch_assoc();

$query3 = "SELECT rating_number3, FORMAT((total_points3 / rating_number3),1) as average_rating3 FROM e3 WHERE post_id = 1 AND status = 1";
$result3 = $db->query($query3);
$ratingRow3 = $result3->fetch_assoc();

$query4 = "SELECT rating_number4, FORMAT((total_points4 / rating_number4),1) as average_rating4 FROM e4 WHERE post_id = 1 AND status = 1";
$result4 = $db->query($query4);
$ratingRow4 = $result4->fetch_assoc();

$query5 = "SELECT rating_number5, FORMAT((total_points5 / rating_number5),1) as average_rating5 FROM e5 WHERE post_id = 1 AND status = 1";
$result5 = $db->query($query5);
$ratingRow5 = $result5->fetch_assoc();

$query6 = "SELECT rating_number6, FORMAT((total_points6 / rating_number6),1) as average_rating6 FROM e6 WHERE post_id = 1 AND status = 1";
$result6 = $db->query($query6);
$ratingRow6 = $result6->fetch_assoc();

$query7 = "SELECT rating_number7, FORMAT((total_points7 / rating_number7),1) as average_rating7 FROM g1 WHERE post_id = 1 AND status = 1";
$result7 = $db->query($query7);
$ratingRow7 = $result7->fetch_assoc();

$query8 = "SELECT rating_number8, FORMAT((total_points8 / rating_number8),1) as average_rating8 FROM g2 WHERE post_id = 1 AND status = 1";
$result8 = $db->query($query8);
$ratingRow8 = $result8->fetch_assoc();

$query9 = "SELECT rating_number9, FORMAT((total_points9 / rating_number9),1) as average_rating9 FROM g3 WHERE post_id = 1 AND status = 1";
$result9 = $db->query($query9);
$ratingRow9 = $result9->fetch_assoc();

$query10 = "SELECT rating_number10, FORMAT((total_points10 / rating_number10),1) as average_rating10 FROM g4 WHERE post_id = 1 AND status = 1";
$result10 = $db->query($query10);
$ratingRow10 = $result10->fetch_assoc();

$query11 = "SELECT rating_number11, FORMAT((total_points11 / rating_number11),1) as average_rating11 FROM g5 WHERE post_id = 1 AND status = 1";
$result11 = $db->query($query11);
$ratingRow11 = $result11->fetch_assoc();

$query12 = "SELECT rating_number12, FORMAT((total_points12 / rating_number12),1) as average_rating12 FROM g6 WHERE post_id = 1 AND status = 1";
$result12 = $db->query($query12);
$ratingRow12 = $result12->fetch_assoc();


$query13 = "SELECT rating_number13, FORMAT((total_points13 / rating_number13),1) as average_rating13 FROM i1 WHERE post_id = 1 AND status = 1";
$result13 = $db->query($query13);
$ratingRow13 = $result13->fetch_assoc();

$query14 = "SELECT rating_number14, FORMAT((total_points14 / rating_number14),1) as average_rating14 FROM i2 WHERE post_id = 1 AND status = 1";
$result14 = $db->query($query14);
$ratingRow14 = $result14->fetch_assoc();

$query15 = "SELECT rating_number15, FORMAT((total_points15 / rating_number15),1) as average_rating15 FROM i3 WHERE post_id = 1 AND status = 1";
$result15 = $db->query($query15);
$ratingRow15 = $result15->fetch_assoc();

$query16 = "SELECT rating_number16, FORMAT((total_points16 / rating_number16),1) as average_rating16 FROM i4 WHERE post_id = 1 AND status = 1";
$result16 = $db->query($query16);
$ratingRow16 = $result16->fetch_assoc();

$query17 = "SELECT rating_number17, FORMAT((total_points17 / rating_number17),1) as average_rating17 FROM i5 WHERE post_id = 1 AND status = 1";
$result17 = $db->query($query17);
$ratingRow17 = $result17->fetch_assoc();

$query18 = "SELECT rating_number18, FORMAT((total_points18 / rating_number18),1) as average_rating18 FROM i6 WHERE post_id = 1 AND status = 1";
$result18 = $db->query($query18);
$ratingRow18 = $result18->fetch_assoc();


$query19 = "SELECT rating_number19, FORMAT((total_points19 / rating_number19),1) as average_rating19 FROM p1 WHERE post_id = 1 AND status = 1";
$result19 = $db->query($query19);
$ratingRow19 = $result19->fetch_assoc();

$query20 = "SELECT rating_number20, FORMAT((total_points20 / rating_number20),1) as average_rating20 FROM p2 WHERE post_id = 1 AND status = 1";
$result20 = $db->query($query20);
$ratingRow20 = $result20->fetch_assoc();

$query21 = "SELECT rating_number21, FORMAT((total_points21 / rating_number21),1) as average_rating21 FROM p3 WHERE post_id = 1 AND status = 1";
$result21 = $db->query($query21);
$ratingRow21 = $result21->fetch_assoc();

$query22 = "SELECT rating_number22, FORMAT((total_points22 / rating_number22),1) as average_rating22 FROM p4 WHERE post_id = 1 AND status = 1";
$result22 = $db->query($query22);
$ratingRow22 = $result22->fetch_assoc();

$query23 = "SELECT rating_number23, FORMAT((total_points23 / rating_number23),1) as average_rating23 FROM p5 WHERE post_id = 1 AND status = 1";
$result23 = $db->query($query23);
$ratingRow23 = $result23->fetch_assoc();

$query24 = "SELECT rating_number24, FORMAT((total_points24 / rating_number24),1) as average_rating24 FROM p6 WHERE post_id = 1 AND status = 1";
$result24 = $db->query($query24);
$ratingRow24 = $result24->fetch_assoc();

$query25 = "SELECT rating_number25, FORMAT((total_points25 / rating_number25),1) as average_rating25 FROM t1 WHERE post_id = 1 AND status = 1";
$result25 = $db->query($query25);
$ratingRow25 = $result25->fetch_assoc();

$query26 = "SELECT rating_number26, FORMAT((total_points26 / rating_number26),1) as average_rating26 FROM t2 WHERE post_id = 1 AND status = 1";
$result26 = $db->query($query26);
$ratingRow26 = $result26->fetch_assoc();

$query27 = "SELECT rating_number27, FORMAT((total_points27 / rating_number27),1) as average_rating27 FROM t3 WHERE post_id = 1 AND status = 1";
$result27 = $db->query($query27);
$ratingRow27 = $result27->fetch_assoc();

$query28 = "SELECT rating_number28, FORMAT((total_points28 / rating_number28),1) as average_rating28 FROM t4 WHERE post_id = 1 AND status = 1";
$result28 = $db->query($query28);
$ratingRow28 = $result28->fetch_assoc();

$query29 = "SELECT rating_number29, FORMAT((total_points29 / rating_number29),1) as average_rating29 FROM t5 WHERE post_id = 1 AND status = 1";
$result29 = $db->query($query29);
$ratingRow29 = $result29->fetch_assoc();

$query30 = "SELECT rating_number30, FORMAT((total_points30 / rating_number30),1) as average_rating30 FROM t6 WHERE post_id = 1 AND status = 1";
$result30 = $db->query($query30);
$ratingRow30 = $result30->fetch_assoc();



?>

<html>

<head>
    <title>Example - Using jQuery .data()</title>
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>
    <style>

        #sidebar {
            display: table-cell;
            background: #DDDDDD;
            padding: 10px 10px 10px 10px;
            width:150px;
        }

        #rows {
            display: table-cell;
            padding-left: 10px;
        }

        .row {
            display: table-row;
        }

        .cell {
            font-family: Hind , sans-serif;
            display: table-cell;
            background:#e3f1fd;
            padding: 5px 5px 5px 5px;
            width:300px;
            height: 70px;
            border: 1px solid white;
        }

    </style>

</head>

<body>

    <div id="sidebar" data-key="Tota">
        Filter by type, users or rating:
        <input type="text" />
        <button id="filter">Filter</button>
        <button id="clear">Clear</button>
        <p>
        To keep the sample code simple, the search terms are "ORed". Example "seafood 2 stars downtown" which return all rows that matches seafood OR 2+ stars OR in dowtown.
        </p>
    </div>

    <div id="rows">

        <p>
        This sample webpage shows how to use the <code>jQuery.data()</code> method. It uses a CSS-based table and a filter function that filters rows based on the data associated with the particular row DOM-element .
        </p>

        <div class="row" id="row1">
            <div class="cell"><b>Entity Name</b></div>
            <div class="cell"><b>Type of website entity</b></div>
            <div class="cell"><b>No. of Users</b></div>
            <div class="cell"><b>Rating</b></div>
        </div>

        <div class="row" id="row2">
            <div class="cell">e-Bay</div>
            <div class="cell">Ecommerce</div>
            <div class="cell"><?php echo $ratingRow['rating_number']; ?></div>
            <div class="cell">  <?php echo $ratingRow['average_rating']; ?></div>
        </div>
 
 <div class="row" id="row3">
            <div class="cell">Myntra</div>
            <div class="cell">reva</div>
            <div class="cell"><?php echo $ratingRow2['rating_number2']; ?></div>
            <div class="cell">  <?php echo $ratingRow2['average_rating2']; ?></div>
        </div>

        <div class="row" id="row4">
            <div class="cell">Shopclues</div>
            <div class="cell">Ecommerce</div>
            <div class="cell"><?php echo $ratingRow3['rating_number3']; ?></div>
            <div class="cell">  <?php echo $ratingRow3['average_rating3']; ?></div>
        </div>

        <div class="row" id="row5">
            <div class="cell">Amazon</div>
            <div class="cell">Ecommerce</div>
            <div class="cell"><?php echo $ratingRow4['rating_number4']; ?></div>
            <div class="cell">  <?php echo $ratingRow4['average_rating4']; ?></div>
        </div>

        <div class="row" id="row6">
            <div class="cell">Snapdeal</div>
            <div class="cell">reva</div>
            <div class="cell"><?php echo $ratingRow5['rating_number5']; ?></div>
            <div class="cell">  <?php echo $ratingRow5['average_rating5']; ?></div>
        </div>

        <div class="row" id="row7">
            <div class="cell">Jabong</div>
            <div class="cell">Ecommerce</div>
            <div class="cell"><?php echo $ratingRow6['rating_number6']; ?></div>
            <div class="cell">  <?php echo $ratingRow6['average_rating6']; ?></div>
        </div>
        
        <div class="row" id="row8">
            <div class="cell">Splinter cell</div>
            <div class="cell">PC Gaming</div>
            <div class="cell"><?php echo $ratingRow7['rating_number7']; ?></div>
            <div class="cell">  <?php echo $ratingRow7['average_rating7']; ?></div>
        </div>
    
        <div class="row" id="row9">
            <div class="cell">Simcity</div>
            <div class="cell">PC Gaming</div>
            <div class="cell"><?php echo $ratingRow8['rating_number8']; ?></div>
            <div class="cell">  <?php echo $ratingRow8['average_rating8']; ?></div>
        </div>

        <div class="row" id="row10">
            <div class="cell">Arkham series</div>
            <div class="cell">PC Gaming</div>
            <div class="cell"><?php echo $ratingRow9['rating_number9']; ?></div>
            <div class="cell">  <?php echo $ratingRow9['average_rating9']; ?></div>
        </div>

        <div class="row" id="row11">
            <div class="cell">AC Series</div>
            <div class="cell">PC Gaming</div>
            <div class="cell"><?php echo $ratingRow10['rating_number10']; ?></div>
            <div class="cell">  <?php echo $ratingRow10['average_rating10']; ?></div>
        </div>

        <div class="row" id="row12">
            <div class="cell">GTA series</div>
            <div class="cell">PC Gaming</div>
            <div class="cell"><?php echo $ratingRow11['rating_number11']; ?></div>
            <div class="cell">  <?php echo $ratingRow11['average_rating11']; ?></div>
        </div>

        <div class="row" id="row13">
            <div class="cell">WD series</div>
            <div class="cell">PC Gaming</div>
            <div class="cell"><?php echo $ratingRow12['rating_number12']; ?></div>
            <div class="cell">  <?php echo $ratingRow12['average_rating12']; ?></div>
        </div>

        <div class="row" id="row14">
            <div class="cell">Coursera</div>
            <div class="cell">info-edu</div>
            <div class="cell"><?php echo $ratingRow13['rating_number13']; ?></div>
            <div class="cell">  <?php echo $ratingRow13['average_rating13']; ?></div>
        </div>

        <div class="row" id="row15">
            <div class="cell">K Acad</div>
            <div class="cell">info-edu</div>
            <div class="cell"><?php echo $ratingRow14['rating_number14']; ?></div>
            <div class="cell">  <?php echo $ratingRow14['average_rating14']; ?></div>
        </div>

        <div class="row" id="row16">
            <div class="cell">Udacity</div>
            <div class="cell">info-edu</div>
            <div class="cell"><?php echo $ratingRow15['rating_number15']; ?></div>
            <div class="cell">  <?php echo $ratingRow15['average_rating15']; ?></div>
        </div>

        <div class="row" id="row17">
            <div class="cell">Codeacademy</div>
            <div class="cell">info-edu</div>
            <div class="cell"><?php echo $ratingRow16['rating_number16']; ?></div>
            <div class="cell">  <?php echo $ratingRow16['average_rating16']; ?></div>
        </div>

        <div class="row" id="row18">
            <div class="cell">Alison</div>
            <div class="cell">info-edu</div>
            <div class="cell"><?php echo $ratingRow17['rating_number17']; ?></div>
            <div class="cell">  <?php echo $ratingRow17['average_rating17']; ?></div>
        </div>

        <div class="row" id="row19">
            <div class="cell">Udemy</div>
            <div class="cell">info-edu</div>
            <div class="cell"><?php echo $ratingRow18['rating_number18']; ?></div>
            <div class="cell">  <?php echo $ratingRow18['average_rating18']; ?></div>
        </div>

        <div class="row" id="row20">
            <div class="cell">bitly</div>
            <div class="cell">Tools</div>
            <div class="cell"><?php echo $ratingRow19['rating_number19']; ?></div>
            <div class="cell">  <?php echo $ratingRow19['average_rating19']; ?></div>
        </div>

        <div class="row" id="row21">
            <div class="cell">Piwik</div>
            <div class="cell">Tools</div>
            <div class="cell"><?php echo $ratingRow20['rating_number20']; ?></div>
            <div class="cell">  <?php echo $ratingRow20['average_rating20']; ?></div>
        </div>

        <div class="row" id="row22">
            <div class="cell">Semrush</div>
            <div class="cell">Tools</div>
            <div class="cell"><?php echo $ratingRow21['rating_number21']; ?></div>
            <div class="cell">  <?php echo $ratingRow21['average_rating21']; ?></div>
        </div>

        <div class="row" id="row23">
            <div class="cell">Google Analytics</div>
            <div class="cell">Tools</div>
            <div class="cell"><?php echo $ratingRow22['rating_number22']; ?></div>
            <div class="cell">  <?php echo $ratingRow22['average_rating22']; ?></div>
        </div>

        <div class="row" id="row24">
            <div class="cell">Similarweb</div>
            <div class="cell">Tools</div>
            <div class="cell"><?php echo $ratingRow23['rating_number23']; ?></div>
            <div class="cell">  <?php echo $ratingRow23['average_rating23']; ?></div>
        </div>

        <div class="row" id="row25">
            <div class="cell">Libarto</div>
            <div class="cell">Tools</div>
            <div class="cell"><?php echo $ratingRow24['rating_number24']; ?></div>
            <div class="cell">  <?php echo $ratingRow24['average_rating24']; ?></div>
        </div>

        <div class="row" id="row26">
            <div class="cell">Activison</div>
            <div class="cell">Products</div>
            <div class="cell"><?php echo $ratingRow25['rating_number25']; ?></div>
            <div class="cell">  <?php echo $ratingRow25['average_rating25']; ?></div>
        </div>

        <div class="row" id="row27">
            <div class="cell">Bethesda </div>
            <div class="cell">Products</div>
            <div class="cell"><?php echo $ratingRow26['rating_number26']; ?></div>
            <div class="cell">  <?php echo $ratingRow26['average_rating26']; ?></div>
        </div>

        <div class="row" id="row28">
            <div class="cell">Bungie</div>
            <div class="cell">Products</div>
            <div class="cell"><?php echo $ratingRow27['rating_number27']; ?></div>
            <div class="cell">  <?php echo $ratingRow27['average_rating27']; ?></div>
        </div>

        <div class="row" id="row29">
            <div class="cell">Square enix</div>
            <div class="cell">Products</div>
            <div class="cell"><?php echo $ratingRow28['rating_number28']; ?></div>
            <div class="cell">  <?php echo $ratingRow28['average_rating28']; ?></div>
        </div>

        <div class="row" id="row30">
            <div class="cell">Treyarch</div>
            <div class="cell">Products</div>
            <div class="cell"><?php echo $ratingRow29['rating_number29']; ?></div>
            <div class="cell">  <?php echo $ratingRow29['average_rating29']; ?></div>
        </div>

        <div class="row" id="row31">
            <div class="cell">Infinity ward</div>
            <div class="cell">Products</div>
            <div class="cell"><?php echo $ratingRow30['rating_number30']; ?></div>
            <div class="cell">  <?php echo $ratingRow30['average_rating30']; ?></div>
        </div>







    </div>


</body>

<script type="text/javascript">

    /* Ready */
    $(document).ready(function() {
        $('#filter').click(function () {
            filterRows($('input').val());
        });
        $('#clear').click(function () {
            $('input').val('')
            clearRows($('input').val());
        });
    });

    /* Associate data to specific DOM-elements */
    $('#row1').data({ id:1, type:'rowheader'});
    $('#row2').data({ id:2, type:'e-Bay', type2:'Ecommerce', stars:'<?php echo $ratingRow['rating_number']; ?>', area:'<?php echo $ratingRow['average_rating']; ?> '});
    $('#row3').data({ id:3, type:'Myntra', type2:'reva',stars:'<?php echo $ratingRow2['rating_number2']; ?>', area:'<?php echo $ratingRow2['average_rating2']; ?>' });
    $('#row4').data({ id:4, type:'Shopclues', type2:'Ecommerce',stars:'<?php echo $ratingRow3['rating_number3']; ?>', area:'<?php echo $ratingRow3['average_rating3']; ?>'});
    $('#row5').data({ id:5, type:'Amazon', type2:'Ecommerce',stars:'<?php echo $ratingRow4['rating_number4']; ?>', area:'<?php echo $ratingRow4['average_rating4']; ?>'});
    $('#row6').data({ id:6, type:'Snapdeal', type2:'reva',stars:'<?php echo $ratingRow5['rating_number5']; ?>', area:'<?php echo $ratingRow5['average_rating5']; ?>'});
    $('#row7').data({ id:7, type:'Jabong', type2:'Ecommerce',stars:'<?php echo $ratingRow6['rating_number6']; ?>', area:'<?php echo $ratingRow6['average_rating6']; ?>'});
    

    $('#row8').data({ id:8, type:'Splinter cell', type2:'PC Gaming', stars:'<?php echo $ratingRow7['rating_number7']; ?>', area:'<?php echo $ratingRow7['average_rating7']; ?> '});
    $('#row9').data({ id:9, type:'Simcity', type2:'PC Gaming',stars:'<?php echo $ratingRow8['rating_number8']; ?>', area:'<?php echo $ratingRow8['average_rating8']; ?>' });
    $('#row10').data({ id:10, type:'Arkam series', type2:'PC Gaming',stars:'<?php echo $ratingRow9['rating_number9']; ?>', area:'<?php echo $ratingRow9['average_rating9']; ?>'});
    $('#row11').data({ id:11, type:'AC series', type2:'Gaming',stars:'<?php echo $ratingRow10['rating_number10']; ?>', area:'<?php echo $ratingRow10['average_rating10']; ?>'});
    $('#row12').data({ id:12, type:'GTA series', type2:'PC Gaming',stars:'<?php echo $ratingRow11['rating_number11']; ?>', area:'<?php echo $ratingRow11['average_rating11']; ?>'});
    $('#row13').data({ id:13, type:'WD series', type2:'Gaming',stars:'<?php echo $ratingRow12['rating_number12']; ?>', area:'<?php echo $ratingRow12['average_rating12']; ?>'});

    $('#row14').data({ id:14, type:'Coursera', type2:'info-edu', stars:'<?php echo $ratingRow13['rating_number13']; ?>', area:'<?php echo $ratingRow13['average_rating13']; ?> '});
    $('#row15').data({ id:15, type:'k Acad', type2:'reva',stars:'<?php echo $ratingRow14['rating_number14']; ?>', area:'<?php echo $ratingRow14['average_rating14']; ?>' });
    $('#row16').data({ id:16, type:'Udacity', type2:'info-edu',stars:'<?php echo $ratingRow15['rating_number15']; ?>', area:'<?php echo $ratingRow15['average_rating15']; ?>'});
    $('#row17').data({ id:17, type:'Codeacademy', type2:'info-edu',stars:'<?php echo $ratingRow16['rating_number16']; ?>', area:'<?php echo $ratingRow16['average_rating16']; ?>'});
    $('#row18').data({ id:18, type:'Alison', type2:'reva',stars:'<?php echo $ratingRow17['rating_number17']; ?>', area:'<?php echo $ratingRow17['average_rating17']; ?>'});
    $('#row19').data({ id:19, type:'Udemy', type2:'info-edu',stars:'<?php echo $ratingRow18['rating_number18']; ?>', area:'<?php echo $ratingRow18['average_rating18']; ?>'});

    $('#row20').data({ id:20, type:'bitly', type2:'Tools', stars:'<?php echo $ratingRow19['rating_number19']; ?>', area:'<?php echo $ratingRow19['average_rating19']; ?> '});
    $('#row21').data({ id:21, type:'Piwik', type2:'Tools',stars:'<?php echo $ratingRow20['rating_number20']; ?>', area:'<?php echo $ratingRow20['average_rating20']; ?>' });
    $('#row22').data({ id:22, type:'Semrush', type2:'Tools',stars:'<?php echo $ratingRow21['rating_number21']; ?>', area:'<?php echo $ratingRow21['average_rating21']; ?>'});
    $('#row23').data({ id:23, type:'google Analytics', type2:'Tools',stars:'<?php echo $ratingRow22['rating_number22']; ?>', area:'<?php echo $ratingRow22['average_rating22']; ?>'});
    $('#row24').data({ id:24, type:'Similarweb', type2:'Tools',stars:'<?php echo $ratingRow23['rating_number23']; ?>', area:'<?php echo $ratingRow23['average_rating23']; ?>'});
    $('#row25').data({ id:25, type:'Libarto', type2:'Tools',stars:'<?php echo $ratingRow24['rating_number24']; ?>', area:'<?php echo $ratingRow24['average_rating24']; ?>'});

    $('#row26').data({ id:26, type:'Activison', type2:'Products', stars:'<?php echo $ratingRow25['rating_number25']; ?>', area:'<?php echo $ratingRow25['average_rating25']; ?> '});
    $('#row27').data({ id:27, type:'Bethesda', type2:'reva',stars:'<?php echo $ratingRow26['rating_number26']; ?>', area:'<?php echo $ratingRow26['average_rating26']; ?>' });
    $('#row28').data({ id:28, type:'Bungie', type2:'Products',stars:'<?php echo $ratingRow27['rating_number27']; ?>', area:'<?php echo $ratingRow27['average_rating27']; ?>'});
    $('#row29').data({ id:29, type:'Square enix', type2:'Products',stars:'<?php echo $ratingRow28['rating_number28']; ?>', area:'<?php echo $ratingRow28['average_rating28']; ?>'});
    $('#row30').data({ id:30, type:'Treyarch', type2:'reva',stars:'<?php echo $ratingRow29['rating_number29']; ?>', area:'<?php echo $ratingRow29['average_rating29']; ?>'});
    $('#row31').data({ id:31, type:'Infinity ward', type2:'Products',stars:'<?php echo $ratingRow30['rating_number30']; ?>', area:'<?php echo $ratingRow30['average_rating30']; ?>'});

    /* Clear Rows */
    function clearRows(filterString) {
        // For each row, that is, div in #rows of class .row
        $.each($('#rows .row'), function(i, row) {
            $(row).show();
        });
    }

    /* Filter Rows */
    function filterRows(filterString) {

        // For each row, that is, div in #rows of class .row
        $.each($('#rows .row'), function(i, row) {
            var $row = $(row); // Get the row div element
            var rowData = $row.data(); // Get the data associated with the row div element
            var id = rowData.id; // Get the row id
            var type = rowData.type;
            if (filterString.length == 0) {
                $row.show();
            } else {
                if (type.toLowerCase().search("rowheader") != -1) {
                    $row.show();
                } else {
                    if (filterByType(filterString, rowData.type) ||
                        filterByType2(filterString, rowData.type2) ||
                        filterByRating(filterString, rowData.stars) ||
                        filterByLocation(filterString, rowData.area)) {
                        $row.show();
                    } else {
                        $row.hide();
                    }
                }

            }

        });
    }

    /* Filter Rows by Type */
    function filterByType(filterString, type) {
        var p1 = RegExp(type);
        if (p1.test(filterString)) {
            return true;
        } else {
            return false;
        }
    }

    function filterByType2(filterString, type2) {
        var p1 = RegExp(type2);
        if (p1.test(filterString)) {
            return true;
        } else {
            return false;
        }
    }





    /* Filter Rows by Rating */
    function filterByRating(filterString, stars) {
        if (filterString.toLowerCase().search('star') != -1) {
            var value = filterString.replace(/[^0-9]/g,'');
            if (stars >= value) {
                return true;
            } else {
                return false;
            }
        }
    }

    /* Filter Rows by Location */
    function filterByLocation(filterString, area) {
        var p1 = RegExp(area);
        if (p1.test(filterString)) {
            return true;
        } else {
            return false;
        }
    }

</script>

</html>
