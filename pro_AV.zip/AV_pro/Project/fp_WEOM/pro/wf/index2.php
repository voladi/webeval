<?php
include_once 'dbConfig.php';
//Fetch rating deatails from database
$query7 = "SELECT rating_number7, FORMAT((total_points7 / rating_number7),1) as average_rating7 FROM g1 WHERE post_id = 1 AND status = 1";
$result7 = $db->query($query7);
$ratingRow7 = $result7->fetch_assoc();

$query8 = "SELECT rating_number8, FORMAT((total_points8 / rating_number8),1) as average_rating8 FROM g2 WHERE post_id = 1 AND status = 1";
$result8 = $db->query($query8);
$ratingRow8 = $result8->fetch_assoc();

$query9 = "SELECT rating_number9, FORMAT((total_points9 / rating_number9),1) as average_rating9 FROM g3 WHERE post_id = 1 AND status = 1";
$result9 = $db->query($query9);
$ratingRow9 = $result9->fetch_assoc();

$query10 = "SELECT rating_number10, FORMAT((total_points10 / rating_number10),1) as average_rating10 FROM g4 WHERE post_id = 1 AND status = 1";
$result10 = $db->query($query10);
$ratingRow10 = $result10->fetch_assoc();

$query11 = "SELECT rating_number11, FORMAT((total_points11 / rating_number11),1) as average_rating11 FROM g5 WHERE post_id = 1 AND status = 1";
$result11 = $db->query($query11);
$ratingRow11 = $result11->fetch_assoc();

$query12 = "SELECT rating_number12, FORMAT((total_points12 / rating_number12),1) as average_rating12 FROM g6 WHERE post_id = 1 AND status = 1";
$result12 = $db->query($query12);
$ratingRow12 = $result12->fetch_assoc();




?>



  <!DOCTYPE html>
  <html>
  <title>W3.CSS Template</title>
  <head>

   <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
  body,h1,h2,h3,h4,h5,h6 {font-family: "Raleway", sans-serif}
  </style>
<link href="rating.css" rel="stylesheet" type="text/css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="rating.js"></script>
<script language="javascript" type="text/javascript">


$(function() {
    $("#rating_star").codexworld_rating_widget({
        starLength: '5',
        initialValue: '',
        callbackFunctionName: 'processRating',
        imageDirectory: 'images/',
        inputAttr: 'postID'
    });
});

$(function() {
    $("#rating_star2").codexworld_rating_widget({
        starLength: '5',
        initialValue: '',
        callbackFunctionName: 'processRating2',
        imageDirectory: 'images/',
        inputAttr: 'postID'
    });
});

$(function() {
    $("#rating_star3").codexworld_rating_widget({
        starLength: '5',
        initialValue: '',
        callbackFunctionName: 'processRating3',
        imageDirectory: 'images/',
        inputAttr: 'postID'
    });
});

$(function() {
    $("#rating_star4").codexworld_rating_widget({
        starLength: '5',
        initialValue: '',
        callbackFunctionName: 'processRating4',
        imageDirectory: 'images/',
        inputAttr: 'postID'
    });
});
$(function() {
    $("#rating_star5").codexworld_rating_widget({
        starLength: '5',
        initialValue: '',
        callbackFunctionName: 'processRating5',
        imageDirectory: 'images/',
        inputAttr: 'postID'
    });
});

$(function() {
    $("#rating_star6").codexworld_rating_widget({
        starLength: '5',
        initialValue: '',
        callbackFunctionName: 'processRating6',
        imageDirectory: 'images/',
        inputAttr: 'postID'
    });
});







function processRating(val, attrVal){
    $.ajax({
        type: 'POST',
        url: 'gaming/rating.php',
        data: 'postID='+attrVal+'&ratingPoints='+val,
        dataType: 'json',
        success : function(data) {
            if (data.status == 'ok') {
                alert('You have rated '+val+' to CodexWorld');
                $('#avgrat').text(data.average_rating7);
                $('#totalrat').text(data.rating_number7);
            }else{
                alert('Some problem occured, please try again.');
            }
        }
    });
}


function processRating2(val, attrVal){
    $.ajax({
        type: 'POST',
        url: 'gaming/rating2.php',
        data: 'postID='+attrVal+'&ratingPoints='+val,
        dataType: 'json',
        success : function(data) {
            if (data.status == 'ok') {
                alert('You have rated '+val+' to CodexWorld');
                $('#avgrat2').text(data.average_rating8);
                $('#totalrat2').text(data.rating_number8);
            }else{
                alert('Some problem occured, please try again.');
            }
        }
    });
}


function processRating3(val, attrVal){
    $.ajax({
        type: 'POST',
        url: 'gaming/rating3.php',
        data: 'postID='+attrVal+'&ratingPoints='+val,
        dataType: 'json',
        success : function(data) {
            if (data.status == 'ok') {
                alert('You have rated '+val+' to CodexWorld');
                $('#avgrat3').text(data.average_rating9);
                $('#totalrat3').text(data.rating_number9);
            }else{
                alert('Some problem occured, please try again.');
            }
        }
    });
}


function processRating4(val, attrVal){
    $.ajax({
        type: 'POST',
        url: 'gaming/rating4.php',
        data: 'postID='+attrVal+'&ratingPoints='+val,
        dataType: 'json',
        success : function(data) {
            if (data.status == 'ok') {
                alert('You have rated '+val+' to CodexWorld');
                $('#avgrat4').text(data.average_rating10);
                $('#totalrat4').text(data.rating_number10);
            }else{
                alert('Some problem occured, please try again.');
            }
        }
    });
}


function processRating5(val, attrVal){
    $.ajax({
        type: 'POST',
        url: 'gaming/rating5.php',
        data: 'postID='+attrVal+'&ratingPoints='+val,
        dataType: 'json',
        success : function(data) {
            if (data.status == 'ok') {
                alert('You have rated '+val+' to CodexWorld');
                $('#avgrat5').text(data.average_rating11);
                $('#totalrat5').text(data.rating_number11);
            }else{
                alert('Some problem occured, please try again.');
            }
        }
    });
}


function processRating6(val, attrVal){
    $.ajax({
        type: 'POST',
        url: 'gaming/rating6.php',
        data: 'postID='+attrVal+'&ratingPoints='+val,
        dataType: 'json',
        success : function(data) {
            if (data.status == 'ok') {
                alert('You have rated '+val+' to CodexWorld');
                $('#avgrat6').text(data.average_rating12);
                $('#totalrat6').text(data.rating_number12);
            }else{
                alert('Some problem occured, please try again.');
            }
        }
    });
}






</script>
<style type="text/css">
    .overall-rating{font-size: 14px;margin-top: 5px;color: #8e8d8d;}
</style>
</head>



  <body class="w3-light-grey w3-content" style="max-width:1600px">

  <!-- Sidebar/menu -->
  <nav class="w3-sidebar w3-collapse w3-white w3-animate-left" style="z-index:3;width:300px;" id="mySidebar"><br>
    <div class="w3-container">
      <a href="#" onclick="w3_close()" class="w3-hide-large w3-right w3-jumbo w3-padding w3-hover-grey" title="close menu">
        <i class="fa fa-remove"></i>
      </a>
      <img src="dp.jpg" style="width:45%;" class="w3-round"><br><br>
      <h4><b>My Profile</b></h4>
      <p class="w3-text-grey">Logged in from GITAM University</p>
    </div>
    <div class="w3-bar-block">
      <a href="#portfolio" onclick="w3_close()" class="w3-bar-item w3-button w3-padding w3-text-teal"><i class="fa fa-th-large fa-fw w3-margin-right"></i>CATALOGUE</a> 
      <a href="#about" onclick="w3_close()" class="w3-bar-item w3-button w3-padding"><i class="fa fa-user fa-fw w3-margin-right"></i>ABOUT</a> 
      <a href="#contact" onclick="w3_close()" class="w3-bar-item w3-button w3-padding"><i class="fa fa-envelope fa-fw w3-margin-right"></i>CONTACT</a>
    </div>
    <div class="w3-panel w3-large">
      <i class="fa fa-facebook-official w3-hover-opacity"></i>
      <i class="fa fa-instagram w3-hover-opacity"></i>
      <i class="fa fa-snapchat w3-hover-opacity"></i>
      <i class="fa fa-pinterest-p w3-hover-opacity"></i>
      <i class="fa fa-twitter w3-hover-opacity"></i>
      <i class="fa fa-linkedin w3-hover-opacity"></i>
    </div>
  </nav>

  <!-- Overlay effect when opening sidebar on small screens -->
  <div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

  <!-- !PAGE CONTENT! -->
  <div class="w3-main" style="margin-left:300px">

    <!-- Header -->
    <header id="portfolio">
      <a href="#"><img src="/w3images/avatar_g2.jpg" style="width:65px;" class="w3-circle w3-right w3-margin w3-hide-large w3-hover-opacity"></a>
      <span class="w3-button w3-hide-large w3-xxlarge w3-hover-text-grey" onclick="w3_open()"><i class="fa fa-bars"></i></span>
      <div class="w3-container">
      <h1><b>Catalogue</b></h1>
      <div class="w3-section w3-bottombar w3-padding-16">
        <span class="w3-margin-right">Filter:</span> 
        <button class="w3-button w3-black">Gaming</button>
        <button class="w3-button w3-white"><i class="fa fa-diamond w3-margin-right"></i><a href="index4.php">Tools</a></button>
        <button class="w3-button w3-white w3-hide-small"><i class="fa fa-photo w3-margin-right"></i><a href="index3.php">Info-edu</a></button>
        <button class="w3-button w3-white w3-hide-small"><i class="fa fa-map-pin w3-margin-right"></i><a href="index.php">E-commerce</a></button>
        <button class="w3-button w3-white w3-hide-small"><i class="fa fa-map-pin w3-margin-right"></i><a href="index5.php">Products</a></button>
      </div>
      </div>
    </header>

    <!-- First Photo Grid-->
    <div class="w3-row-padding">
      <div class="w3-third w3-container w3-margin-bottom">
        <img src="images/g1.jpg" alt="Norway" style="width:100%" class="w3-hover-opacity">
        <div class="w3-container w3-white">
          <p><b>Splinter Cell Conviction</b></p>
          <p>Award winning franchise</p>
              
            <input name="rating" value="0" id="rating_star" type="hidden" postID="1" />
    <div class="overall-rating">(Average Rating <span id="avgrat"><?php echo $ratingRow7['average_rating7']; ?></span>
Based on <span id="totalrat"><?php echo $ratingRow7['rating_number7']; ?></span>  rating)</span></div>

          </p>
        </div>
      </div>
      <div class="w3-third w3-container w3-margin-bottom">
        <img src="images/g2.png" alt="Norway" style="width:100%" class="w3-hover-opacity">
        <div class="w3-container w3-white">
          <p><b>Simcity</b></p>
          <p>Best city simulation tool ever</p>
              
          <input name="rating" value="0" id="rating_star2" type="hidden" postID="1" />
    <div class="overall-rating">(Average Rating <span id="avgrat2"><?php echo $ratingRow8['average_rating8']; ?></span>
Based on <span id="totalrat2"><?php echo $ratingRow8['rating_number8']; ?></span>  rating)</span></div>

          </p>
        </div>
      </div>
      <div class="w3-third w3-container">
        <img src="images/g3.jpg" alt="Norway" style="width:100%" class="w3-hover-opacity">
        <div class="w3-container w3-white">
          <p><b>Arkham series</b></p>
          <p> Best of batman </p>
              
          <input name="rating" value="0" id="rating_star3" type="hidden" postID="1" />
    <div class="overall-rating">(Average Rating <span id="avgrat3"><?php echo $ratingRow9['average_rating9']; ?></span>
Based on <span id="totalrat3"><?php echo $ratingRow9['rating_number9']; ?></span>  rating)</span></div>

          </p>
        </div>
      </div>
    </div>

    <!-- Second Photo Grid-->
    <div class="w3-row-padding">
      <div class="w3-third w3-container w3-margin-bottom">
        <img src="images/g4.jpg" alt="Norway" style="width:100%" class="w3-hover-opacity">
        <div class="w3-container w3-white">
          <p><b>AC Series</b></p>
          <p> Ubisoft's best efforts </p>
              
          <input name="rating" value="0" id="rating_star4" type="hidden" postID="1" />
    <div class="overall-rating">(Average Rating <span id="avgrat4"><?php echo $ratingRow10['average_rating10']; ?></span>
Based on <span id="totalrat4"><?php echo $ratingRow10['rating_number10']; ?></span>  rating)</span></div>

          </p>
        </div>
      </div>
      <div class="w3-third w3-container w3-margin-bottom">
        <img src="images/g5.jpg" alt="Norway" style="width:100%" class="w3-hover-opacity">
        <div class="w3-container w3-white">
          <p><b>GTA series</b></p>
          <p> arguably the best gaming product </p>
              
          <input name="rating" value="0" id="rating_star5" type="hidden" postID="1" />
    <div class="overall-rating">(Average Rating <span id="avgrat5"><?php echo $ratingRow11['average_rating11']; ?></span>
Based on <span id="totalrat5"><?php echo $ratingRow11['rating_number11']; ?></span>  rating)</span></div>

          </p>
        </div>
      </div>
      <div class="w3-third w3-container">
        <img src="images/g6.jpg" alt="Norway" style="width:100%" class="w3-hover-opacity">
        <div class="w3-container w3-white">
          <p><b>WD Series</b></p>
          <p> hype </p>
              
          <input name="rating" value="0" id="rating_star6" type="hidden" postID="1" />
    <div class="overall-rating">(Average Rating <span id="avgrat6"><?php echo $ratingRow12['average_rating12']; ?></span>
Based on <span id="totalrat6"><?php echo $ratingRow12['rating_number12']; ?></span>  rating)</span></div>

          </p>
        </div>
      </div>
    </div>

    <!-- Pagination -->
    <div class="w3-center w3-padding-32">
      <div class="w3-bar">
        <a href="index4.php" class="w3-bar-item w3-button w3-hover-black">«</a>
        <a href="index5.php" class="w3-bar-item w3-black w3-button">1</a>
        <a href="index.php" class="w3-bar-item w3-button w3-hover-black">2</a>
        <a href="index2.php" class="w3-bar-item w3-button w3-hover-black">3</a>
        <a href="index3.php" class="w3-bar-item w3-button w3-hover-black">4</a>
        <a href="index3.php" class="w3-bar-item w3-button w3-hover-black">»</a>
      </div>
    </div>

    <div class="w3-container w3-padding-large" style="margin-bottom:32px">
      <h4><b>About page</b></h4>
      <p> Each tool is unique and rating helps in determining what's the best choice of public.</p>
      <hr>

      <hr class="w3-opacity">
      <form  >
        <div class="w3-section">
          <label>Name</label>
          <input class="w3-input w3-border" type="text" name="Name" required>
        </div>
        <div class="w3-section">
          <label>Email</label>
          <input class="w3-input w3-border" type="text" name="Email" required>
        </div>
        <div class="w3-section">
          <label>Message</label>
          <input class="w3-input w3-border" type="text" name="Message" required>
        </div>
        <button class="w3-button w3-black w3-margin-bottom"><i class="fa fa-paper-plane w3-margin-right"></i>Send Message</button>
      </form>
    </div>

    <!-- Footer -->
    <footer class="w3-container w3-padding-32 w3-dark-grey">
    <div class="w3-row-padding">
      <div class="w3-third">
        <h3>FOOTER</h3>
        <p>Developed by Batch 12 <br> B7 CSE 4/4 <br> GITAM University .</p>
        
      </div>

      <div class="w3-third">
        <h3>BLOG POSTS</h3>
        <ul class="w3-ul w3-hoverable">
          <li class="w3-padding-16">
           
            <span class="w3-large">Volcox</span><br>
            <span>" great tools"</span>
          </li>
          <li class="w3-padding-16">
           
            <span class="w3-large">"John"</span><br>
            <span>" Easy to use"</span>
          </li> 
        </ul>
      </div>

      <div class="w3-third">
        <h3>POPULAR TAGS</h3>
        <p>
          <span class="w3-tag w3-black w3-margin-bottom">Travel</span> <span class="w3-tag w3-grey w3-small w3-margin-bottom">New York</span> <span class="w3-tag w3-grey w3-small w3-margin-bottom">London</span>
          <span class="w3-tag w3-grey w3-small w3-margin-bottom">IKEA</span> <span class="w3-tag w3-grey w3-small w3-margin-bottom">NORWAY</span> <span class="w3-tag w3-grey w3-small w3-margin-bottom">DIY</span>
          <span class="w3-tag w3-grey w3-small w3-margin-bottom">Ideas</span> <span class="w3-tag w3-grey w3-small w3-margin-bottom">Baby</span> <span class="w3-tag w3-grey w3-small w3-margin-bottom">Family</span>
          <span class="w3-tag w3-grey w3-small w3-margin-bottom">News</span> <span class="w3-tag w3-grey w3-small w3-margin-bottom">Clothing</span> <span class="w3-tag w3-grey w3-small w3-margin-bottom">Shopping</span>
          <span class="w3-tag w3-grey w3-small w3-margin-bottom">Sports</span> <span class="w3-tag w3-grey w3-small w3-margin-bottom">Games</span>
        </p>
      </div>

    </div>
    </footer>

    <div class="w3-black w3-center w3-padding-24">Powered by Ramya Ma'am </a></div>

  <!-- End page content -->
  </div>

  <script>
  // Script to open and close sidebar
  function w3_open() {
      document.getElementById("mySidebar").style.display = "block";
      document.getElementById("myOverlay").style.display = "block";
  }

  function w3_close() {
      document.getElementById("mySidebar").style.display = "none";
      document.getElementById("myOverlay").style.display = "none";
  }
  </script>

  </body>
  </html>














