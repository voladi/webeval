<?php
include_once 'dbConfig.php';
if(!empty($_POST['ratingPoints'])){
    $postID = $_POST['postID'];
    $ratingNum = 1;
    $ratingPoints = $_POST['ratingPoints'];
    
    //Check the rating row with same post ID
    $prevRatingQuery = "SELECT * FROM i1 WHERE post_id = ".$postID;
    $prevRatingResult = $db->query($prevRatingQuery);
    if($prevRatingResult->num_rows > 0):
        $prevRatingRow = $prevRatingResult->fetch_assoc();
        $ratingNum = $prevRatingRow['rating_number13'] + $ratingNum;
        $ratingPoints = $prevRatingRow['total_points13'] + $ratingPoints;
        //Update rating data into the database
        $query = "UPDATE i1 SET rating_number13 = '".$ratingNum."', total_points13 = '".$ratingPoints."', modified = '".date("Y-m-d H:i:s")."' WHERE post_id = ".$postID;
        $update = $db->query($query);
    else:
        //Insert rating data into the database
        $query = "INSERT INTO i1 (post_id,rating_number13,total_points13,created,modified) VALUES(".$postID.",'".$ratingNum."','".$ratingPoints."','".date("Y-m-d H:i:s")."','".date("Y-m-d H:i:s")."')";
        $insert = $db->query($query);
    endif;
    
    //Fetch rating deatails from database
    $query = "SELECT rating_number13, FORMAT((total_points13 / rating_number13),1) as average_rating13 FROM i1 WHERE post_id = ".$postID." AND status = 1";
    $result = $db->query($query);
    $ratingRow13 = $result->fetch_assoc();
    
    if($ratingRow13){
        $ratingRow13['status'] = 'ok';
    }else{
        $ratingRow13['status'] = 'err';
    }
    
    //Return json formatted rating data
    echo json_encode($ratingRow13);
}
?>