<?php
include_once 'dbConfig.php';
if(!empty($_POST['ratingPoints'])){
    $postID = $_POST['postID'];
    $ratingNum = 1;
    $ratingPoints = $_POST['ratingPoints'];
    
    //Check the rating row with same post ID
    $prevRatingQuery = "SELECT * FROM i5 WHERE post_id = ".$postID;
    $prevRatingResult = $db->query($prevRatingQuery);
    if($prevRatingResult->num_rows > 0):
        $prevRatingRow = $prevRatingResult->fetch_assoc();
        $ratingNum = $prevRatingRow['rating_number17'] + $ratingNum;
        $ratingPoints = $prevRatingRow['total_points17'] + $ratingPoints;
        //Update rating data into the database
        $query = "UPDATE i5 SET rating_number17 = '".$ratingNum."', total_points17 = '".$ratingPoints."', modified = '".date("Y-m-d H:i:s")."' WHERE post_id = ".$postID;
        $update = $db->query($query);
    else:
        //Insert rating data into the database
        $query = "INSERT INTO i5 (post_id,rating_number17,total_points17,created,modified) VALUES(".$postID.",'".$ratingNum."','".$ratingPoints."','".date("Y-m-d H:i:s")."','".date("Y-m-d H:i:s")."')";
        $insert = $db->query($query);
    endif;
    
    //Fetch rating deatails from database
    $query = "SELECT rating_number17, FORMAT((total_points17 / rating_number17),1) as average_rating17 FROM i5 WHERE post_id = ".$postID." AND status = 1";
    $result5 = $db->query($query);
    $ratingRow17 = $result5->fetch_assoc();
    
    if($ratingRow17){
        $ratingRow17['status'] = 'ok';
    }else{
        $ratingRow17['status'] = 'err';
    }
    
    //Return json formatted rating data
    echo json_encode($ratingRow17);
}
?>