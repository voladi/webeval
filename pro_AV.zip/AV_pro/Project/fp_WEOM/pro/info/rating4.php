<?php
include_once 'dbConfig.php';
if(!empty($_POST['ratingPoints'])){
    $postID = $_POST['postID'];
    $ratingNum = 1;
    $ratingPoints = $_POST['ratingPoints'];
    
    //Check the rating row with same post ID
    $prevRatingQuery = "SELECT * FROM i4 WHERE post_id = ".$postID;
    $prevRatingResult = $db->query($prevRatingQuery);
    if($prevRatingResult->num_rows > 0):
        $prevRatingRow = $prevRatingResult->fetch_assoc();
        $ratingNum = $prevRatingRow['rating_number16'] + $ratingNum;
        $ratingPoints = $prevRatingRow['total_points16'] + $ratingPoints;
        //Update rating data into the database
        $query = "UPDATE i4 SET rating_number16 = '".$ratingNum."', total_points16 = '".$ratingPoints."', modified = '".date("Y-m-d H:i:s")."' WHERE post_id = ".$postID;
        $update = $db->query($query);
    else:
        //Insert rating data into the database
        $query = "INSERT INTO i4 (post_id,rating_number16,total_points16,created,modified) VALUES(".$postID.",'".$ratingNum."','".$ratingPoints."','".date("Y-m-d H:i:s")."','".date("Y-m-d H:i:s")."')";
        $insert = $db->query($query);
    endif;
    
    //Fetch rating deatails from database
    $query = "SELECT rating_number16, FORMAT((total_points16 / rating_number16),1) as average_rating16 FROM i4 WHERE post_id = ".$postID." AND status = 1";
    $result4 = $db->query($query);
    $ratingRow16 = $result4->fetch_assoc();
    
    if($ratingRow16){
        $ratingRow16['status'] = 'ok';
    }else{
        $ratingRow16['status'] = 'err';
    }
    
    //Return json formatted rating data
    echo json_encode($ratingRow16);
}
?>