<?php
include_once 'dbConfig.php';
if(!empty($_POST['ratingPoints'])){
    $postID = $_POST['postID'];
    $ratingNum = 1;
    $ratingPoints = $_POST['ratingPoints'];
    
    //Check the rating row with same post ID
    $prevRatingQuery = "SELECT * FROM i3 WHERE post_id = ".$postID;
    $prevRatingResult = $db->query($prevRatingQuery);
    if($prevRatingResult->num_rows > 0):
        $prevRatingRow = $prevRatingResult->fetch_assoc();
        $ratingNum = $prevRatingRow['rating_number15'] + $ratingNum;
        $ratingPoints = $prevRatingRow['total_points15'] + $ratingPoints;
        //Update rating data into the database
        $query = "UPDATE i3 SET rating_number15 = '".$ratingNum."', total_points15 = '".$ratingPoints."', modified = '".date("Y-m-d H:i:s")."' WHERE post_id = ".$postID;
        $update = $db->query($query);
    else:
        //Insert rating data into the database
        $query = "INSERT INTO i3 (post_id,rating_number15,total_points15,created,modified) VALUES(".$postID.",'".$ratingNum."','".$ratingPoints."','".date("Y-m-d H:i:s")."','".date("Y-m-d H:i:s")."')";
        $insert = $db->query($query);
    endif;
    
    //Fetch rating deatails from database
    $query = "SELECT rating_number15, FORMAT((total_points15 / rating_number15),1) as average_rating15 FROM i3 WHERE post_id = ".$postID." AND status = 1";
    $result3 = $db->query($query);
    $ratingRow15 = $result3->fetch_assoc();
    
    if($ratingRow15){
        $ratingRow15['status'] = 'ok';
    }else{
        $ratingRow15['status'] = 'err';
    }
    
    //Return json formatted rating data
    echo json_encode($ratingRow15);
}
?>